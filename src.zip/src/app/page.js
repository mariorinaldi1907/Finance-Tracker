import HomePage from './homepage';

export default function RootPage() {
  return <HomePage />;
}