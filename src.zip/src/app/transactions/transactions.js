export default function TransactionsPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Transactions</h1>
      <p>We’ll list your latest transactions here.</p>
    </main>
  );
}