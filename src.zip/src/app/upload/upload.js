export default function UploadPage() {
  return (
    <main style={{ padding: 24 }}>
      <h1>Upload CSV</h1>
      <p>This page will let you choose a CSV and map columns.</p>
    </main>
  );
}