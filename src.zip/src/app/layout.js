import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { createServerClient } from "@/lib/serverClient";

const geistSans = Geist({ variable: "--font-geist-sans", subsets: ["latin"] });
const geistMono = Geist_Mono({ variable: "--font-geist-mono", subsets: ["latin"] });

export const metadata = {
  title: "Finance Tracker",
  description: "Import DBS CSVs, categorize spending, and view dashboards.",
};

export default async function RootLayout({ children }) {
  const supabase = await createServerClient();            // ← await
  const { data: { session } } = await supabase.auth.getSession();

  const link = { color: "#2563eb", textDecoration: "underline", marginRight: 12 };

  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable}`} style={{ minHeight: "100vh" }}>
        <header style={{ padding: 16, borderBottom: "1px solid #e5e7eb" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", maxWidth: 960, margin: "0 auto" }}>
            <a href="/homepage" style={{ fontWeight: 700, fontSize: 18, color: "inherit", textDecoration: "none" }}>
              Finance Tracker
            </a>
            <nav>
              {session ? (
                <>
                  <a href="/upload" style={link}>Upload</a>
                  <a href="/transactions" style={link}>Transactions</a>
                  <a href="/dashboard" style={link}>Dashboard</a>
                  <a href="/logout" style={link}>Log out</a>
                </>
              ) : (
                <>
                  <a href="/login" style={link}>Log in</a>
                  <a href="/signup" style={link}>Sign up</a>
                </>
              )}
            </nav>
          </div>
        </header>
        <main style={{ maxWidth: 960, margin: "0 auto", padding: 24 }}>
          {children}
        </main>
      </body>
    </html>
  );
}